<?php
if (basename($_SERVER["REQUEST_URI"]) === basename(__FILE__))
{
  header('Location: index.php?e=404');exit;
}
?>
<div class="alert alert-info">
<h5 class="active"><a href="home.php"><i class="ficon fad fa-home text-warning"></i><span class="menu-item" data-i18n="Inicio"> INICIO</span></a></h5>
</div>
<!--#####-->
<section id="input-with-icons">
    <div class="row match-height">
        <div class="col-12">
            <div class="card border-info mb-3">
                
				<p>
				</p>
                <div class="card-content">
<center><p class="px-0"><b>ESSE CAMPO É PARA TROCA DA LOGO INICIAL.</b></p></center>
<div class="alert-info">
<center><p class="px-1"><b>ESSA É SUA LOGO INICIAL ATUAL</b></p></center>
<center><p class="login-box-msg">IMAGEM DEVERÁ SER EM PNG <br>
    DETALHES: <b>310X70 px</b></p></center>
	<p>
                <div class="avatar-content">
                                <center><img class="rounded-lg" src="../logo/login2.png" alt="logologin" height="70" width="310"></img></center>
	</p>							
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebeUpload.php">
       
	  <center><input name="arquivo" type="file" />
       <input type="submit" value="Salvar" /> </center><br/>
	   <p>
				</p>
    </form>
</div>
<center><p class="px-0"><b>ESSE CAMPO É PARA TROCA DA LOGO MENU.</b></p></center>
<div class="alert-info">
<center><p class="px-1"><b>ESSA É SUA LOGO MENU ATUAL</b></center>
<center><p class="login-box-msg">IMAGEM DEVERÁ SER EM PNG <br>
    DETALHEs: <b>220X35 px</b></p></center>
	<p>
                <div class="avatar-content">
                                <center><img class="rounded-lg" src="../logo/logomenu.png" alt="logomenu" height="40" width="230"></img></center>
	</p>							
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebeUpload2.php">
       
	  <center><input name="arquivo" type="file" />
       <input type="submit" value="Salvar" /> </center><br/>
    </form>   
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Input with Icons end -->
<!--#####-->

</div>